<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PatricPoba\MtnMomo\MtnConfig;
use PatricPoba\MtnMomo\MtnCollection;
use Ibracilinks\OrangeMoney\OrangeMoney;
use App\Models\Payer;
use Cookie;

class PayerController extends Controller
{
    
public function index()
{
        return view('payer.smspayer');
}

    

public function orange(Request $request)
{

         $orange="orange";
         $trans="0";
        $status="0";
        $amount = $request->amount;
        $numero = $request->numero;
        $prix = $request->prix;// volume de sms
        $nom = $request->nom;
       
        $payment = new OrangeMoney();

        $order_id = "orangeapi".rand(100000,900000)."_00".rand(10000,90000);
     

        $data = [
            "merchant_key"=> '*******',
            "currency"=> "OUV",
            "order_id"=>  $order_id,
            "amount" => $amount,
            "return_url"=> "http://orangeapi.test/lastpartorange?order_id=$order_id&amount=$amount&nom=$nom&prix=$prix&numero=$numero",
            "cancel_url"=> 'http://orangeapi.test/',
            "notif_url"=>  'http://orangeapi.test/sms_payement.php',
            "lang"=> "fr",
            "reference"=> "Produit orangeapi"
        ];
        
    
        $result= $payment->webPayment($data);
        $payment= $result['payment_url'];
     
        
        $pay_token=$result['pay_token'];
        Cookie::queue('pay_token', $pay_token, '10');

        return view('retour_orange.retourorange',[
           
            'pay_token'=>$pay_token,
            'payment'=>$payment,
            'orange'=>$orange,
            'amount'=>$amount,
            'trans'=>$trans,
            'status'=> $status,
            'numero'=>$numero,
            'prix'=>$prix,
            'nom'=>$nom,
           
            ]);
    

}
public function orangeretour(Request $request)
{
    
    $prix = $request->prix;//volume de sms
    $nom = $request->nom;
    $numero = $request->numero;
    $orange = $request->orange;
    $payment = $request->payment;
    $pay_token = $request->pay_token;
   
    
    $payment = $request->payment;
    return redirect ($payment);
    

}

public function orangelastretour(Request $request)
{
    $trans='1';
    $pay_token = $request->cookie('pay_token');
    $prix = $request->prix; //volume de sms
    $nom = $request->nom;
    $order_id = $request->order_id;
    $amount = $request->amount;
    $numero = $request->numero;
    $orange = 'orange';
    $payment = $request->payment;
    
   
   
    
    $payment = new OrangeMoney();
    $rep= $payment->checkTransactionStatus($order_id,$amount,$pay_token);
    $status= $rep['status'];
    
    
     if($status == "SUCCESS"){
        $paye = new Payer;
       
        $paye->reseau= $orange;
        $paye->volume_sms= $prix;
        $paye->trans= $pay_token;
        $paye->status= $status;
        $paye->numero= $numero;
        $paye->prix= $amount;
        $paye->nom= $nom;
       
        $paye->save();
          
    }
    if($status == "FAILED"){
        $payer = new Payer;
       
        $payer->reseau= $orange;
        $payer->volume_sms= $prix;
        $payer->trans= $pay_token;
        $payer->status= $status;
        $payer->numero= $numero;
        $payer->prix= $amount;
        $payer->nom= $nom;
        $payer->save();

           
    }
        
        return view('retour_orange.retourorange',[
        'pay_token'=>$pay_token,
        'payment'=>$payment,
        'orange'=> $orange,
        'status'=> $status,
        'trans'=> $trans,
        'amount'=>$amount,
        'numero'=>$numero,
        'prix'=>$prix,
        'nom'=>$nom,
        ]);
    
    

}

}
